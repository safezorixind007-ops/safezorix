import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Industries from './components/Industries';
import About from './components/About';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import StickyCallButton from './components/StickyCallButton';
import PrivacyPolicy from './components/PrivacyPolicy';

const App: React.FC = () => {
    const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);

    return (
        <div className="bg-gray-50 text-gray-800 font-sans">
            <Header />
            <main>
                <Hero />
                <Services />
                <Industries />
                <About />
                <Gallery />
                <Testimonials />
                <FAQ />
                <Contact />
            </main>
            <Footer onShowPrivacy={() => setShowPrivacyPolicy(true)} />
            <StickyCallButton />
            <PrivacyPolicy show={showPrivacyPolicy} onClose={() => setShowPrivacyPolicy(false)} />
        </div>
    );
};

export default App;