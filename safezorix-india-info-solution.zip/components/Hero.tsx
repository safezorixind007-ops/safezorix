import React from 'react';

const Hero: React.FC = () => {
    const scrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <section id="home" className="relative h-screen flex items-center justify-center text-white">
            <div className="absolute inset-0 bg-black opacity-60"></div>
            <img src="https://images.unsplash.com/photo-1588621412235-ef3503b4d538?q=80&w=1920&auto=format&fit=crop" alt="A modern, high-definition CCTV security camera mounted on a wall, symbolizing advanced surveillance and security." className="absolute inset-0 w-full h-full object-cover" />
            
            <div className="relative z-10 text-center px-4">
                <h1 className="text-4xl md:text-6xl font-extrabold mb-4 leading-tight" style={{textShadow: '2px 2px 4px rgba(0,0,0,0.7)'}}>
                    Your Security, Our Priority
                </h1>
                <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8" style={{textShadow: '1px 1px 2px rgba(0,0,0,0.7)'}}>
                    Providing comprehensive, state-of-the-art security solutions across India for over 30 years.
                </p>
                <a 
                    href="#contact"
                    onClick={scrollToContact}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-lg"
                >
                    Request a Free Quote
                </a>
            </div>
        </section>
    );
};

export default Hero;