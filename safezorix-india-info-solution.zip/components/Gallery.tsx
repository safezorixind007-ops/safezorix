import React, { useState } from 'react';
import { GALLERY_IMAGES_DATA } from '../constants';

const Gallery: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const goToPrevious = () => {
        const isFirstSlide = currentIndex === 0;
        const newIndex = isFirstSlide ? GALLERY_IMAGES_DATA.length - 1 : currentIndex - 1;
        setCurrentIndex(newIndex);
    };

    const goToNext = () => {
        const isLastSlide = currentIndex === GALLERY_IMAGES_DATA.length - 1;
        const newIndex = isLastSlide ? 0 : currentIndex + 1;
        setCurrentIndex(newIndex);
    };

    const currentImage = GALLERY_IMAGES_DATA[currentIndex];

    return (
        <section id="gallery" className="py-20 bg-gray-50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Our Work in Action</h2>
                    <p className="mt-4 text-lg text-gray-600">
                        A glimpse into our professional installations and advanced security technology.
                    </p>
                </div>
                
                <div className="max-w-4xl mx-auto relative group" aria-roledescription="carousel" aria-label="Project gallery">
                    {/* Image Container */}
                    <div className="relative h-80 md:h-[500px] w-full overflow-hidden rounded-lg shadow-2xl">
                         <div aria-live="polite" aria-atomic="true">
                            {GALLERY_IMAGES_DATA.map((image, index) => (
                                <div 
                                    key={index}
                                    role="group"
                                    aria-roledescription="slide"
                                    aria-label={`Image ${index + 1} of ${GALLERY_IMAGES_DATA.length}`}
                                    className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${index === currentIndex ? 'opacity-100 z-10' : 'opacity-0'}`}
                                >
                                    <img 
                                        src={image.src} 
                                        alt={image.alt} 
                                        className="w-full h-full object-cover"
                                    />
                                </div>
                            ))}
                        </div>
                         {/* Caption */}
                        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent text-white z-20">
                            <h3 className="font-bold text-lg">{currentImage.caption}</h3>
                        </div>
                    </div>

                    {/* Previous Button */}
                    <button 
                        onClick={goToPrevious}
                        aria-label="Previous image"
                        className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white/50 hover:bg-white/80 text-gray-800 p-3 rounded-full shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all opacity-0 group-hover:opacity-100 z-20"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                        </svg>
                    </button>

                    {/* Next Button */}
                    <button 
                        onClick={goToNext}
                        aria-label="Next image"
                        className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white/50 hover:bg-white/80 text-gray-800 p-3 rounded-full shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all opacity-0 group-hover:opacity-100 z-20"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                    </button>
                    
                    {/* Dots indicator */}
                    <div className="flex justify-center mt-4 space-x-2">
                        {GALLERY_IMAGES_DATA.map((_, index) => (
                            <button
                                key={index}
                                onClick={() => setCurrentIndex(index)}
                                aria-label={`Go to image ${index + 1}`}
                                className={`w-3 h-3 rounded-full ${currentIndex === index ? 'bg-blue-600' : 'bg-gray-300'} hover:bg-blue-400 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
                            ></button>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Gallery;
