
import React from 'react';

const About: React.FC = () => {
    return (
        <section id="about" className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="flex flex-col md:flex-row items-center gap-12">
                    <div className="md:w-1/2">
                        <img 
                            src="https://picsum.photos/800/600?random=4" 
                            alt="Team of professional Safezorix technicians" 
                            className="rounded-lg shadow-2xl w-full"
                        />
                    </div>
                    <div className="md:w-1/2">
                        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">About Safezorix India</h2>
                        <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                            With over 30 years of collective experience in the security industry, Safezorix India Info Solution has established itself as a trusted leader in safeguarding homes, businesses, and communities. Our mission is to provide reliable, cutting-edge security technology combined with exceptional customer service. We are committed to excellence, integrity, and the peace of mind of our clients.
                        </p>
                        <p className="text-gray-600 text-lg leading-relaxed">
                            Our team of highly skilled and certified technicians is dedicated to designing and implementing customized security systems that meet your specific needs. We stay ahead of the curve, continuously adopting the latest advancements to offer you the most effective protection available.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default About;
