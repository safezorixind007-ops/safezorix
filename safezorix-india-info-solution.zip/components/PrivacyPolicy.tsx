import React from 'react';

interface PrivacyPolicyProps {
    show: boolean;
    onClose: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ show, onClose }) => {
    if (!show) {
        return null;
    }

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
            aria-modal="true"
            role="dialog"
            onClick={onClose}
        >
            <div 
                className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-8 relative"
                onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside the modal
            >
                <button 
                    onClick={onClose} 
                    className="absolute top-4 right-4 text-gray-500 hover:text-gray-800"
                    aria-label="Close privacy policy"
                >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Privacy Policy</h2>
                <div className="text-gray-600 space-y-4 max-h-[70vh] overflow-y-auto pr-4">
                    <p>
                        This Privacy Policy describes how Safezorix India Info Solution ("we", "us", or "our") collects, uses, and discloses your personal information when you use our website and contact form.
                    </p>
                    <h3 className="text-lg font-semibold text-gray-700 pt-2">Information We Collect</h3>
                    <p>
                        When you use the contact form on our website, we collect the personal information you provide to us, including:
                    </p>
                    <ul className="list-disc list-inside">
                        <li>Name</li>
                        <li>Email address</li>
                        <li>Phone number</li>
                        <li>Service of interest</li>
                        <li>Your message</li>
                    </ul>
                    <h3 className="text-lg font-semibold text-gray-700 pt-2">How We Use Your Information</h3>
                    <p>
                        The information you provide through the contact form is used solely for the purpose of responding to your inquiries, providing you with a quote, or scheduling a free demo. We use your contact details to communicate with you about your request.
                    </p>
                    <h3 className="text-lg font-semibold text-gray-700 pt-2">Data Sharing and Disclosure</h3>
                    <p>
                        We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties. Your data is kept confidential and is used only for internal communication purposes.
                    </p>
                     <h3 className="text-lg font-semibold text-gray-700 pt-2">Data Security</h3>
                    <p>
                        We implement a variety of security measures to maintain the safety of your personal information when you submit a request.
                    </p>
                    <p>
                        By using our contact form, you consent to our privacy policy.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default PrivacyPolicy;