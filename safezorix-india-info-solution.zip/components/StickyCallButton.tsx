
import React from 'react';

const StickyCallButton: React.FC = () => {
    return (
        <a 
            href="tel:7689952294"
            className="md:hidden fixed bottom-4 right-4 bg-blue-600 text-white px-5 py-3 rounded-full shadow-lg flex items-center gap-2 z-50 hover:bg-blue-700 transition-colors"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C6.477 18 2 13.523 2 8V5a1 1 0 011-1h.001z" />
            </svg>
            <span className="font-semibold">Call Now</span>
        </a>
    );
};

export default StickyCallButton;
