import React, { useState, FormEvent } from 'react';
import { SERVICES_DATA } from '../constants';

const Contact: React.FC = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        service: '',
        message: '',
    });
    const [formStatus, setFormStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
    const [statusMessage, setStatusMessage] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setFormStatus('loading');
        setStatusMessage('Sending your request...');

        // Simulate API call
        try {
            // In a real app, you would post to your endpoint:
            // await fetch('YOUR_API_ENDPOINT', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(formData),
            // });
            await new Promise(resolve => setTimeout(resolve, 1500)); // Mock network delay
            
            // Mock success/error
            if (formData.email.includes('error')) {
                 throw new Error("Failed to send message.");
            }

            setFormStatus('success');
            setStatusMessage('Thank you! Your request has been sent successfully. We will contact you shortly.');
            setFormData({ name: '', email: '', phone: '', service: '', message: '' });
        } catch (error) {
            setFormStatus('error');
            setStatusMessage('Sorry, something went wrong. Please try again or call us directly.');
        }
    };

    return (
        <section id="contact" className="py-20 bg-gray-100">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Get in Touch</h2>
                    <p className="mt-4 text-lg text-gray-600">Request a quote or ask a question. We're here to help.</p>
                </div>

                <div className="flex flex-col lg:flex-row gap-12">
                    {/* Contact Form */}
                    <div className="lg:w-1/2 bg-white p-8 rounded-lg shadow-lg">
                        <h3 className="text-2xl font-bold mb-6">Request a Quote / Get Free Demo</h3>
                        <form onSubmit={handleSubmit}>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <input type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleChange} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500" required />
                                <input type="email" name="email" placeholder="Your Email" value={formData.email} onChange={handleChange} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500" required />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <input type="tel" name="phone" placeholder="Phone Number" value={formData.phone} onChange={handleChange} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500" required />
                                 <select name="service" value={formData.service} onChange={handleChange} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500" required>
                                    <option value="">Select a Service</option>
                                    {SERVICES_DATA.map(s => <option key={s.title} value={s.title}>{s.title}</option>)}
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div className="mb-6">
                                <textarea name="message" placeholder="Your Message" value={formData.message} onChange={handleChange} rows={5} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500" required></textarea>
                            </div>
                            <button type="submit" disabled={formStatus === 'loading'} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition duration-300 disabled:bg-gray-400">
                                {formStatus === 'loading' ? 'Sending...' : 'Send Request'}
                            </button>
                             {formStatus !== 'idle' && (
                                <p className={`mt-4 text-center ${formStatus === 'success' ? 'text-green-600' : ''} ${formStatus === 'error' ? 'text-red-600' : ''}`}>
                                    {statusMessage}
                                </p>
                            )}
                        </form>
                    </div>

                    {/* Contact Info & Map */}
                    <div className="lg:w-1/2">
                        <div className="bg-white p-8 rounded-lg shadow-lg mb-8">
                            <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                            <div className="space-y-4 text-gray-700">
                                <p><strong>Address:</strong> Near Nobel School, Tonk, Rajasthan, India</p>
                                <p><strong>Phone:</strong> <a href="tel:7689952294" className="text-blue-600 hover:underline">76899 52294</a></p>
                                <p><strong>Email:</strong> <a href="mailto:safezorixind007@gmail.com" className="text-blue-600 hover:underline">safezorixind007@gmail.com</a></p>
                            </div>
                        </div>
                        <div className="rounded-lg shadow-lg overflow-hidden h-80">
                           <iframe
                                title="Safezorix Office Location"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57148.6635952679!2d75.75037084058204!3d26.16012470768134!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396e10d33017f86d%3A0x94836c3476483495!2sTonk%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1680000000000!5m2!1sen!2sin"
                                width="100%"
                                height="100%"
                                style={{ border: 0 }}
                                allowFullScreen={true}
                                loading="lazy"
                                referrerPolicy="no-referrer-when-downgrade"
                            ></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Contact;