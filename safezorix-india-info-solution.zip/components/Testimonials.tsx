
import React from 'react';
import { TESTIMONIALS_DATA } from '../constants';

const Testimonials: React.FC = () => {
    return (
        <section id="testimonials" className="py-20 bg-blue-600 text-white">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold">What Our Clients Say</h2>
                    <p className="mt-4 text-lg text-blue-100">
                        We are proud to have earned the trust of our clients across India.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {TESTIMONIALS_DATA.map((testimonial, index) => (
                        <div key={index} className="bg-white/10 p-8 rounded-lg backdrop-blur-sm shadow-lg flex flex-col">
                            <p className="text-blue-100 italic mb-6 flex-grow">"{testimonial.quote}"</p>
                            <div>
                                <p className="font-bold text-white">{testimonial.author}</p>
                                <p className="text-blue-200 text-sm">{testimonial.company}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;
