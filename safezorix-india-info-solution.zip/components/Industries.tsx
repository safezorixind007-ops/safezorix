
import React from 'react';

const Industries: React.FC = () => {
    const industries = [
        'Residential', 'Commercial Offices', 'Retail Stores',
        'Warehouses', 'Educational Institutions', 'Hospitality',
        'Healthcare Facilities', 'Industrial & Manufacturing'
    ];

    return (
        <section id="industries" className="py-20 bg-gray-100">
            <div className="container mx-auto px-6 text-center">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Industries We Serve</h2>
                <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto mb-12">
                    Our security solutions are tailored to meet the unique challenges of various sectors.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                    {industries.map((industry, index) => (
                        <span key={index} className="bg-white text-blue-800 text-base font-semibold px-4 py-2 rounded-full shadow-sm">
                            {industry}
                        </span>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Industries;
