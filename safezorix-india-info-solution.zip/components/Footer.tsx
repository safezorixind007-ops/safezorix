import React from 'react';
import { SOCIAL_MEDIA_DATA } from '../constants';

interface FooterProps {
    onShowPrivacy: () => void;
}

const Footer: React.FC<FooterProps> = ({ onShowPrivacy }) => {
    const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
        e.preventDefault();
        document.querySelector(href)?.scrollIntoView({
            behavior: 'smooth'
        });
    };
    
    return (
        <footer className="bg-gray-800 text-white">
            <div className="container mx-auto px-6 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div>
                        <h3 className="text-xl font-bold mb-4">Safezorix India</h3>
                        <p className="text-gray-400">Your trusted partner in security solutions. Protecting people and property across India.</p>
                    </div>
                    <div>
                        <h3 className="text-xl font-bold mb-4">Quick Links</h3>
                        <ul className="space-y-2">
                            <li><a href="#home" onClick={(e) => scrollToSection(e, '#home')} className="text-gray-400 hover:text-white">Home</a></li>
                            <li><a href="#services" onClick={(e) => scrollToSection(e, '#services')} className="text-gray-400 hover:text-white">Services</a></li>
                            <li><a href="#about" onClick={(e) => scrollToSection(e, '#about')} className="text-gray-400 hover:text-white">About Us</a></li>
                            <li><a href="#contact" onClick={(e) => scrollToSection(e, '#contact')} className="text-gray-400 hover:text-white">Contact</a></li>
                             <li>
                                <a 
                                    href="#privacy" 
                                    onClick={(e) => {
                                        e.preventDefault();
                                        onShowPrivacy();
                                    }} 
                                    className="text-gray-400 hover:text-white cursor-pointer"
                                >
                                    Privacy Policy
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-xl font-bold mb-4">Contact Us</h3>
                        <ul className="space-y-2 text-gray-400">
                            <li>Near Nobel School, Tonk, Rajasthan</li>
                            <li><a href="tel:7689952294" className="hover:text-white">76899 52294</a></li>
                            <li><a href="mailto:safezorixind007@gmail.com" className="hover:text-white">safezorixind007@gmail.com</a></li>
                        </ul>
                    </div>
                     <div>
                        <h3 className="text-xl font-bold mb-4">Connect With Us</h3>
                        <div className="flex space-x-4">
                            {SOCIAL_MEDIA_DATA.map(social => (
                                <a
                                    key={social.name}
                                    href={social.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    aria-label={`Follow us on ${social.name}`}
                                    className="text-gray-400 hover:text-white transition-colors duration-300"
                                >
                                    <social.icon className="w-6 h-6" />
                                </a>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-gray-900 py-4 text-center text-gray-500">
                <p>&copy; {new Date().getFullYear()} Safezorix India Info Solution. All Rights Reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;