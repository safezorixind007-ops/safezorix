import React from 'react';

export interface Service {
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
    title: string;
    description: string;
}

export interface Testimonial {
    quote: string;
    author: string;
    company: string;
}

export interface GalleryImage {
    src: string;
    alt: string;
    caption: string;
}

export interface FAQItem {
    question: string;
    answer: string;
}

export interface SocialMediaLink {
    name: string;
    url: string;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
}