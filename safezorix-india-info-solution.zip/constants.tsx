import type { Service, Testimonial, GalleryImage, FAQItem, SocialMediaLink } from './types';
import React from 'react';

// SVG Icon Components
const CameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);

const ShieldCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.944a11.955 11.955 0 019-2.606 11.955 11.955 0 019 2.606c-.311-2.986-1.354-5.694-3.382-8.016z" />
    </svg>
);

const LocationMarkerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const LockClosedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
);

const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
);

// Social Media Icons
const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
    </svg>
);

const TwitterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.5-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.75 2.81 1.91 3.56-.71 0-1.37-.22-1.95-.55v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.94.07 4.28 4.28 0 0 0 4 2.98 8.52 8.52 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.44 20.29 5.7 21 8.12 21 16 21 20.33 14.46 20.33 8.79c0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.23z"></path>
    </svg>
);

const LinkedInIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path>
    </svg>
);

const InstagramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.069-1.645-.069-4.85s.011-3.584.069-4.85c.149-3.225 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163m0-2.163C8.74 0 8.333.011 7.053.069 2.59.215.215 2.59.069 7.053.011 8.333 0 8.74 0 12s.011 3.667.069 4.947c.147 4.46 2.522 6.835 6.984 6.984 1.28.058 1.687.069 4.947.069s3.667-.011 4.947-.069c4.46-.149 6.835-2.523 6.984-6.984.058-1.28.069-1.687.069-4.947s-.011-3.667-.069-4.947C21.41.215 19.035 0 14.573 0 13.293.011 12.88 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.88 1.44 1.44 0 000-2.88z"></path>
    </svg>
);


export const SERVICES_DATA: Service[] = [
    {
        icon: CameraIcon,
        title: 'CCTV Installation',
        description: 'We provide state-of-the-art CCTV camera installation for homes, offices, and commercial properties. Our expert technicians ensure optimal placement and configuration for maximum coverage and clarity, keeping your premises secure 24/7.'
    },
    {
        icon: ShieldCheckIcon,
        title: 'Security System Maintenance',
        description: 'Ensure your security systems are always running at peak performance with our comprehensive maintenance services. We offer regular check-ups, software updates, and prompt repairs to prevent any lapses in your security.'
    },
    {
        icon: LocationMarkerIcon,
        title: 'GPS Tracking Systems',
        description: 'Monitor your vehicles and valuable assets in real-time with our advanced GPS tracking solutions. Ideal for fleet management and personal vehicle security, providing you with location data, alerts, and detailed reports.'
    },
    {
        icon: LockClosedIcon,
        title: 'Access Control Systems',
        description: 'Manage and restrict entry to your property with our sophisticated access control systems. We offer biometric, card-based, and keypad solutions to ensure only authorized personnel can access sensitive areas.'
    },
     {
        icon: EyeIcon,
        title: '24/7 Video Monitoring',
        description: 'Our dedicated team provides round-the-clock video monitoring services, actively watching over your property. We respond immediately to any suspicious activity, ensuring a rapid response to potential threats.'
    }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
    {
        quote: 'Safezorix provided a seamless installation process from start to finish. Their technicians were professional and the camera quality is excellent. I feel much safer at home now.',
        author: 'Ravi Kumar',
        company: 'Homeowner, Delhi'
    },
    {
        quote: 'The GPS tracking system for our fleet has been a game-changer. We have improved efficiency and security significantly. The Safezorix team offered great support throughout.',
        author: 'Priya Sharma',
        company: 'Logistics Manager, Mumbai'
    },
    {
        quote: 'We entrusted Safezorix with the security of our new office, and they delivered beyond our expectations. The access control and CCTV systems work flawlessly. Highly recommended!',
        author: 'Ankit Gupta',
        company: 'IT Firm CEO, Bangalore'
    }
];

export const GALLERY_IMAGES_DATA: GalleryImage[] = [
    { src: 'https://picsum.photos/600/400?random=11', alt: 'Technician installing a dome CCTV camera on a ceiling', caption: 'Precision Installation' },
    { src: 'https://picsum.photos/600/400?random=12', alt: 'Close-up of a high-definition bullet security camera', caption: 'HD Surveillance' },
    { src: 'https://picsum.photos/600/400?random=13', alt: 'Control room with multiple screens showing CCTV feeds', caption: '24/7 Monitoring Center' },
    { src: 'https://picsum.photos/600/400?random=14', alt: 'A person using a smartphone app to view live security camera footage', caption: 'Mobile Live Feed' },
    { src: 'https://picsum.photos/600/400?random=15', alt: 'An employee using a keycard for an access control system', caption: 'Secure Access Control' },
    { src: 'https://picsum.photos/600/400?random=16', alt: 'A fleet of trucks equipped with GPS tracking devices', caption: 'Fleet Management' },
    { src: 'https://picsum.photos/600/400?random=17', alt: 'Various types of CCTV cameras displayed', caption: 'Advanced CCTV Solutions' },
    { src: 'https://picsum.photos/600/400?random=18', alt: 'GPS tracking interface on a digital map', caption: 'Accurate GPS Tracking' },
];

export const FAQ_DATA: FAQItem[] = [
    {
        question: 'What types of CCTV cameras do you offer?',
        answer: 'We offer a wide range of cameras including dome cameras, bullet cameras, PTZ (Pan-Tilt-Zoom) cameras, and wireless cameras from leading brands. We can recommend the best type based on your specific security needs and environment.'
    },
    {
        question: 'Can I view the camera footage remotely?',
        answer: 'Absolutely. All our modern CCTV systems come with remote viewing capabilities. You can monitor the live feed from your cameras on your smartphone, tablet, or computer from anywhere in the world with an internet connection.'
    },
    {
        question: 'How long does a typical installation take?',
        answer: 'The installation time varies depending on the size of the property and the number of cameras. A standard home installation can typically be completed in a single day, while larger commercial projects may take longer. We provide a clear timeline before starting any work.'
    },
    {
        question: 'Do you provide after-sales support and maintenance?',
        answer: 'Yes, we pride ourselves on our excellent after-sales support. We offer Annual Maintenance Contracts (AMCs) to ensure your system remains in optimal condition, and our support team is always available to assist with any issues.'
    }
];

export const SOCIAL_MEDIA_DATA: SocialMediaLink[] = [
    { name: 'Facebook', url: 'https://www.facebook.com/share/1BEJKqxM51/', icon: FacebookIcon },
    { name: 'Twitter', url: 'https://x.com/safezorixind', icon: TwitterIcon },
    { name: 'LinkedIn', url: 'https://www.linkedin.com/in/safezorix-india-info-solution-826b7a386', icon: LinkedInIcon },
    { name: 'Instagram', url: 'https://www.instagram.com/safezorix_india_info_solution', icon: InstagramIcon },
];